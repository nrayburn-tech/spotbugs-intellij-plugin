class A {
    public static void main(String args[]) {
        System.out.println(args[0].replace("x", "y"));
    }
}
