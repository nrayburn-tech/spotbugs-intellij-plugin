final class ProtectedMemberOfFinalClass {
    protected int foo;

    protected void bar() {
    }
}
