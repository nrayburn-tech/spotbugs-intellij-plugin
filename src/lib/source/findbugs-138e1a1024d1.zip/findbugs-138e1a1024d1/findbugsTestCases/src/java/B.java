public class B implements I1 /* , I2 */{
    @Override
    public void i1() {
        System.out.println("B.i1()");
    }
    // public void i2() { System.out.println("B.i2()"); }
}
