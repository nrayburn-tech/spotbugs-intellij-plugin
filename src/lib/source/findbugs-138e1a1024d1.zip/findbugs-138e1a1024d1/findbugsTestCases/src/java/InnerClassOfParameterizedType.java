public class InnerClassOfParameterizedType<T> {
    class Node {
        T value;

        Node next;
    }

}
