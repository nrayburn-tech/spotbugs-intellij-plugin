public class FalseException {
    // This class is not an exception
}
