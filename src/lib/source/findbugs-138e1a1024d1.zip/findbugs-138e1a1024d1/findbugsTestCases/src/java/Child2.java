
public class Child2 extends Parent {

    public static void main(String[] args) {

    }

}
