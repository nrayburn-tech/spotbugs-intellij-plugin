The source for this projects is licensed under the LGPL v 2.1
that can be found in the file LICENSE.txt

The class JavaProjectHelper is copied from different versions of the same class
found in the JDT project. It is licensed under the Eclipse Public License v1.0,
that can be found at: http://www.eclipse.org/legal/epl-v10.html  