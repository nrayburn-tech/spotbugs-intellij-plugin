public class MakeFieldStaticResolutionExample {
    final static String GREETING = "Hello World";
}
