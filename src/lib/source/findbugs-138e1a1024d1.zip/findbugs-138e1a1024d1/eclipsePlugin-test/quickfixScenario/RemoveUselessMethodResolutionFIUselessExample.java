public class RemoveUselessMethodResolutionFIUselessExample {
    @Override
    protected void finalize() throws Throwable {
        super.finalize();
    }
}
